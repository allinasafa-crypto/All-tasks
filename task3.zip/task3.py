# Task 1: String Slicing Practice
# Create a string name = "Programming"
# # Print the following:
 
# # First 5 letters
name = "Programming"
print(name[0:5])

# # Last 3 letters
name = "Programming"
print(name[-3:])

# # Letters from index 2 to 6
name = "Programming"
print(name[2:7])

# # Whole string except the last 2 letters
name = "Programming"
print(name[0:9])

# # The length of the string
name = "Programming"
print(len(name))