# Taking input from user
name = input("Enter your name: ")
age = input("Enter your age: ")
phone = input("Enter your phone number: ")

# Displaying output using f-string
print(f"Dear {name},\n\nWe have received your request. Your age is {age} and we will contact you on this number {phone}.")
